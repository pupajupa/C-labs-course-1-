/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../task4/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[29];
    char stringdata0[499];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 19), // "on_pushback_clicked"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 15), // "on_show_clicked"
QT_MOC_LITERAL(4, 48, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(5, 70, 18), // "on_maxsize_clicked"
QT_MOC_LITERAL(6, 89, 19), // "on_capacity_clicked"
QT_MOC_LITERAL(7, 109, 15), // "on_size_clicked"
QT_MOC_LITERAL(8, 125, 16), // "on_clear_clicked"
QT_MOC_LITERAL(9, 142, 15), // "on_data_clicked"
QT_MOC_LITERAL(10, 158, 15), // "on_back_clicked"
QT_MOC_LITERAL(11, 174, 16), // "on_empty_clicked"
QT_MOC_LITERAL(12, 191, 16), // "on_erase_clicked"
QT_MOC_LITERAL(13, 208, 16), // "on_front_clicked"
QT_MOC_LITERAL(14, 225, 17), // "on_insert_clicked"
QT_MOC_LITERAL(15, 243, 16), // "on_begin_clicked"
QT_MOC_LITERAL(16, 260, 17), // "on_cbegin_clicked"
QT_MOC_LITERAL(17, 278, 17), // "on_rbegin_clicked"
QT_MOC_LITERAL(18, 296, 14), // "on_end_clicked"
QT_MOC_LITERAL(19, 311, 15), // "on_cend_clicked"
QT_MOC_LITERAL(20, 327, 15), // "on_rend_clicked"
QT_MOC_LITERAL(21, 343, 18), // "on_reserve_clicked"
QT_MOC_LITERAL(22, 362, 17), // "on_resize_clicked"
QT_MOC_LITERAL(23, 380, 22), // "on_emplaceback_clicked"
QT_MOC_LITERAL(24, 403, 18), // "on_emplace_clicked"
QT_MOC_LITERAL(25, 422, 13), // "on_at_clicked"
QT_MOC_LITERAL(26, 436, 17), // "on_assign_clicked"
QT_MOC_LITERAL(27, 454, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(28, 478, 20) // "on_swapGener_clicked"

    },
    "MainWindow\0on_pushback_clicked\0\0"
    "on_show_clicked\0on_pushButton_clicked\0"
    "on_maxsize_clicked\0on_capacity_clicked\0"
    "on_size_clicked\0on_clear_clicked\0"
    "on_data_clicked\0on_back_clicked\0"
    "on_empty_clicked\0on_erase_clicked\0"
    "on_front_clicked\0on_insert_clicked\0"
    "on_begin_clicked\0on_cbegin_clicked\0"
    "on_rbegin_clicked\0on_end_clicked\0"
    "on_cend_clicked\0on_rend_clicked\0"
    "on_reserve_clicked\0on_resize_clicked\0"
    "on_emplaceback_clicked\0on_emplace_clicked\0"
    "on_at_clicked\0on_assign_clicked\0"
    "on_pushButton_2_clicked\0on_swapGener_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      27,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  149,    2, 0x08 /* Private */,
       3,    0,  150,    2, 0x08 /* Private */,
       4,    0,  151,    2, 0x08 /* Private */,
       5,    0,  152,    2, 0x08 /* Private */,
       6,    0,  153,    2, 0x08 /* Private */,
       7,    0,  154,    2, 0x08 /* Private */,
       8,    0,  155,    2, 0x08 /* Private */,
       9,    0,  156,    2, 0x08 /* Private */,
      10,    0,  157,    2, 0x08 /* Private */,
      11,    0,  158,    2, 0x08 /* Private */,
      12,    0,  159,    2, 0x08 /* Private */,
      13,    0,  160,    2, 0x08 /* Private */,
      14,    0,  161,    2, 0x08 /* Private */,
      15,    0,  162,    2, 0x08 /* Private */,
      16,    0,  163,    2, 0x08 /* Private */,
      17,    0,  164,    2, 0x08 /* Private */,
      18,    0,  165,    2, 0x08 /* Private */,
      19,    0,  166,    2, 0x08 /* Private */,
      20,    0,  167,    2, 0x08 /* Private */,
      21,    0,  168,    2, 0x08 /* Private */,
      22,    0,  169,    2, 0x08 /* Private */,
      23,    0,  170,    2, 0x08 /* Private */,
      24,    0,  171,    2, 0x08 /* Private */,
      25,    0,  172,    2, 0x08 /* Private */,
      26,    0,  173,    2, 0x08 /* Private */,
      27,    0,  174,    2, 0x08 /* Private */,
      28,    0,  175,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_pushback_clicked(); break;
        case 1: _t->on_show_clicked(); break;
        case 2: _t->on_pushButton_clicked(); break;
        case 3: _t->on_maxsize_clicked(); break;
        case 4: _t->on_capacity_clicked(); break;
        case 5: _t->on_size_clicked(); break;
        case 6: _t->on_clear_clicked(); break;
        case 7: _t->on_data_clicked(); break;
        case 8: _t->on_back_clicked(); break;
        case 9: _t->on_empty_clicked(); break;
        case 10: _t->on_erase_clicked(); break;
        case 11: _t->on_front_clicked(); break;
        case 12: _t->on_insert_clicked(); break;
        case 13: _t->on_begin_clicked(); break;
        case 14: _t->on_cbegin_clicked(); break;
        case 15: _t->on_rbegin_clicked(); break;
        case 16: _t->on_end_clicked(); break;
        case 17: _t->on_cend_clicked(); break;
        case 18: _t->on_rend_clicked(); break;
        case 19: _t->on_reserve_clicked(); break;
        case 20: _t->on_resize_clicked(); break;
        case 21: _t->on_emplaceback_clicked(); break;
        case 22: _t->on_emplace_clicked(); break;
        case 23: _t->on_at_clicked(); break;
        case 24: _t->on_assign_clicked(); break;
        case 25: _t->on_pushButton_2_clicked(); break;
        case 26: _t->on_swapGener_clicked(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 27)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 27;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 27)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 27;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
